/// WARNING DETECTED - WILL BE BANNED WITHIN 5 HOURS///
/// You will be banned, this cheat is detected      ///
/// Use on a alt account                            ///
                         

1. Open csgo.exe.
2. Open Xenox.exe.
3. Select csgo.exe in Xenox Proccess's.
4. Select the .dll file in Xenox.
5. Click inject.
6. 'Ins' is the toggle key - may take few seconds.

- If it doesnt work disable antivirus
- Its completely your fualt if you get banned

--MHEmpire.